﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Tetris
{
	/// <summary>
	/// classical.xaml 的交互逻辑
	/// </summary>
	public partial class classical : Page
	{
		public classical()
		{
			this.InitializeComponent();
			
			// 在此点之下插入创建对象所需的代码。
		}

        private void easybtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void middlebtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hardbtn_Click(object sender, RoutedEventArgs e)
        {

        }
	}
}