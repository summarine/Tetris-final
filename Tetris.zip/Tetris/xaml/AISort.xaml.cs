﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tetris
{
	/// <summary>
	/// AISort.xaml 的交互逻辑
	/// </summary>
	public partial class AISort : UserControl
	{
		public AISort()
		{
			this.InitializeComponent();
		}

        private void AiTwo_Click(object sender, RoutedEventArgs e)
        {
            AIFighting aifighting = new AIFighting();
            aifighting.Show();
        }

        private void AiPeople_Click(object sender, RoutedEventArgs e)
        {
               //AIWindow aiwindow = new AIWindow();
             //aiwindow.Show();
              DoublePlayer doubleplay = new DoublePlayer();
             doubleplay.Show();

        }
	}
}