﻿/***************************************Copyritht Information:Summer Group's work************************************/
/****************************************Team Member: Zheng Peiwen Xia Xiaochan**************************************/
/*******************************************Team Member: Liu Hao Zhao Xiaochao***************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Collections;
namespace Tetris
{
    class ScoreRating
    {
        //public void WriteIntxt()
        //{
        //    //stream in scores to txt
        //    OverScoringBoard scoring = new OverScoringBoard();
        //    Console.WriteLine(scoring.ToString());
        //    FileStream aFile = new FileStream("../score.txt", FileMode.OpenOrCreate);
        //    StreamWriter sw = new StreamWriter(aFile);
        //    sw.Close();
        //}
        ////
        //public static List<String[]> ReadOuttxt(string path)
        //{
        //    List<String[]> ls = new List<String[]>();
        //    string strLine = "";
        //    /// 文件地址
        //    if (File.Exists(path) == true)
        //    {
        //        StreamReader fileReader = new StreamReader(path);
        //        while (strLine != null)
        //        {
        //            strLine = fileReader.ReadLine();
        //            if (strLine != null && strLine.Length > 0)
        //            {
        //                ls.Add(strLine.Split(' '));   //以空格做分隔符

        //                fileReader.Close();
        //                return ls;
        //            }
        //        }
        //        // an arraylist

        //    }

        //}
    }
}
